<?php

include_once './Model/usuarios.php';
include_once './Model/mail.php';

#var_dump($_POST);#


#verifica que el boton submit sea precionado
if (isset($_POST['submit'])) {

    #verifica que todas las validaciones sean correctas
    if (validaciones()) {
        
        $usuarios = new Usuarios();
        $mail = new Mail();
        
        #inserta los datos en bbdd
        $usuarios->create();

        $mail->activarUserMail($_POST['user']);

        #header('location : ./login.php');
    
    } else{
        echo "validaciones incorrectas verificar campos";
    }
}


function validaciones(){

    /* VALIDACIONES */

    $cont = 0;

    # Caracteres alphanumericos, prohibe caracteres especiales, max 100 caracteres
    if (preg_match("/^[a-zA-Z0-9_]{3,100}+$/", $_POST['nombre'])) {
        echo"nombre correcto</br>";
        $cont+= 1;
    }else{
        echo "nombre incorrecto </br>";
    }

    if (preg_match("/^[a-zA-Z0-9_]{3,100}+$/", $_POST['apellidos'])) {
        echo"apellido correcto</br>";
        $cont+=1;
    }else{
        echo "apellido incorrecto </br>";
    }

    #Max 20, interger
    if (preg_match("/^[0-9]{3,20}+$/", $_POST['documento'])) {
        echo"documento correcto</br>";
        $cont+=1;
    }else{
        echo "documento incorrecto </br>";
    }

    #Max 20, no caracteres espciales
    if (preg_match("/^[a-zA-Z0-9_]{3,20}+$/", $_POST['user'])) {
        echo"user correcto</br>";
        $cont+=1;
    }else{
        echo "user incorrecto </br>";
    }

    #Max 20,min 6
    if (preg_match("/^[a-zA-Z0-9_]{3,20}+$/", $_POST['pass'])) {
        echo"password correcto</br>";
        $cont+=1;
    }else{
        echo "password incorrecto </br>";
    }

    #Max 20,min 6
    if (preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $_POST['correo'])) {
        echo"correo correcto</br>";
        $cont+=1;
    }else{
        echo "correo incorrecto </br>";
    }

    #integrer
    if (preg_match("/[0-9]/", $_POST['tipo'])) {
        echo"tipo correcto</br>";
        $cont+=1;
    }else{
        echo "tipo incorrecto </br>";
    }

    #integrer
    if (preg_match("/[0-9]/", $_POST['dependencia'])) {
        echo"depedencia correcto</br>";
        $cont+=1;
    }else{
        echo "dependecia incorrecto </br>";
    }

    return $cont == 8;
}
