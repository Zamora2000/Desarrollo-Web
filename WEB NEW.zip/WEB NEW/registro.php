<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./View/assets/style/style.css">
    <title>Formulario</title>
</head>
<body>
    
    <section class="form-register">
    <form action="./validaciones.php" method="POST" >
        <h4>Formulario Registro</h4>

        <input class="controls" type="text" name="nombre" id="nombre" placeholder="Ingrese su Nombre" required>
        <input class="controls" type="text" name="apellidos" id="apellidos" placeholder="Ingrese su Apellido" >
        <input class="controls" type="number" name="documento" id="documento" placeholder="Numero de documento">
      
        <input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo" >
        
<select class="controls" name="tipo" id="tipo">
    <option value="">--Tipo --</option>
    <option value="2">ADMINISTRATIVO</option>
    <option value="1">PROFESOR</option>
</select>
        <input class="controls" type="text" name="user" id="user" placeholder="Ingrese el usuario"  >
     
        <input class="controls" type="password" name="pass" id="pass" placeholder="Ingrese la contraseña"  >
            
        <select class="controls" name="dependencia" id="dependencia">
    <option value="">--Dependencia --</option>
    <option value="1">FACULTADA DE INGENIERIA</option>
    <option value="2">ADMIN EN SALUD</option>
</select>

        <input name="submit" class="botons" type="submit" value="enviar" id="submit" > 


    </form>
</section>

</body>
<script src="./View/assets/js/main.js"></script>
</html>