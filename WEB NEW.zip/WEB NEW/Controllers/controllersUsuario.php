<?php

class ControllerUsuarios{

    #crea un nuevo cliente
    public function Create(){
        
        require_once  ("./Model/usuarios.php");

        $Usuario = new Usuarios();

        #verifica si el boton agregar con el name salvar fue presionado
        if(isset($_POST['salvar'])){
            #llama al metodo create
            $Usuario->create();
            
            #header('Location: ./login.php' );
            #header('location: /dasboard/View/Usuario.php');
        }

    }

    public function Delete(){

        require_once  ("/xampp/htdocs/dasboard/Model/Usuarios.php");

        $Usuario = new Usuarios();

        #verifica si hay una solicitud de tipo de get
        if(isset($_GET['id'])){
            #llama al metodo delete delete
            $Usuario->delete($_GET['id']);

            header('location: /dasboard/View/Usuario.php');
        }
    }

    public function Read(){
        require_once  ("/xampp/htdocs/dasboard/Model/Usuarios.php");

        $Usuario = new Usuarios();

        $cont = 1;
        #recorre todos los datos en la base de datos
        foreach ($Usuario->getAll() as $key => $value) {
            
            $datos = array(
                        "name" => $value->NOMBRE,
                        "t_ident" => $value->TIPO_IDENTIDAD,
                        "n_ident" => $value->NUM_IDENTIDAD,
                        "address"=> $value->DIRECCION,
                        "email" => $value->EMAIL,
                        "cel" => $value->CEL,
                        "id" =>$value->ID
                    );

            $json = json_encode($datos);

            echo "<tr>";
            echo  "<th scope='row'>".$cont."</th>";
            echo  "<td >" . $value->NOMBRE . "</td>";
            echo  "<td >" . $value->TIPO_IDENTIDAD . "</td>";
            echo  "<td >" . $value->NUM_IDENTIDAD . "</td>";
            echo  "<td >" . $value->DIRECCION . "</td>";
            echo  "<td >" . $value->EMAIL . "</td>";
            echo  "<td >" . $value->CEL . "</td>";
            echo  "<td>

            <div class='d-flex justify-content-center'>

            <a href='/dasboard/View/Login.php?controller=Cliente&action=delete&id=$value->ID' class='btn btn-danger mr-1'>ELIMINAR</a> 
             
            <a class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#staticBackdrop1' onclick='enviar( $json)'> EDITAR</a>
            </div>

            </td>";
            echo "</tr>";
            $cont++;

           
        }
    }

    
    public function Update(){

        require_once  ("/xampp/htdocs/dasboard/Model/Usuarios.php");

        $Usuario = new Usuarios();

        #verifica si hay una solicitud de tipo de get
        if(isset($_POST['editar'])){
            #llama al metodo delete delete
            $Usuario->update($_GET['id']);

            header('location: /dasboard/View/Usuario.php');
        }
        
    }

    #actualiza la contraseña por id
    public function UpdatePass(){

        require_once  ("./Model/Usuarios.php");

        $Usuario = new Usuarios();

        #verifica si hay una solicitud de tipo de get
        if(isset($_POST['btnCambPass'])){
            #llama al metodo delete delete
            $Usuario->updatePass($_POST['id']);

            header('location: ./login.php');
        }
        
    }

     #imprime el numero de registros en tabla Usuario
     public function getAll(){
        require_once("/xampp/htdocs/dasboard/Model/Usuarios.php");

        $Usuario = new Usuarios();
        echo count($Usuario->getAll());
        
    }

}
