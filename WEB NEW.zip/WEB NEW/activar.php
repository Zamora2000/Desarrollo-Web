<?php

include_once './Model/usuarios.php';


$user = new Usuarios();

$key =$_GET['key'];

#verifica que la contraseña encryptada sea la misma 
if ($user->getByPass($key)->PASSWORD == $key) {

    #actualiza el estado del usuario por id
    $user->updateEstado($user->getByPass($key)->ID);

    echo "usuario Activo";

    header('Location: ./login.php');
    
}else{
    echo "La contraseña no coincide";
} 